import tkinter as tk
from tkinter import messagebox
from db_manager import DatabaseManager
import password_generator  # Import the generator module
import viewpassword        # Import the view passwords module

class LoginPage:
    def __init__(self, master, db):
        self.master = master
        self.db = db
        master.title("Login")
        master.geometry("300x200")

        tk.Label(master, text="Username:").pack(pady=5)
        self.username_entry = tk.Entry(master)
        self.username_entry.pack(pady=5)

        tk.Label(master, text="Password:").pack(pady=5)
        self.password_entry = tk.Entry(master, show="*")
        self.password_entry.pack(pady=5)

        tk.Button(master, text="Login", command=self.login).pack(pady=5)
        tk.Button(master, text="Register", command=self.register).pack(pady=5)

    def login(self):
        username = self.username_entry.get().strip()
        password = self.password_entry.get().strip()
        user_id = self.db.login_user(username, password)
        if user_id:
            messagebox.showinfo("Success", "Login successful!")
            self.master.destroy()
            self.open_main_menu(user_id)
        else:
            messagebox.showerror("Error", "Invalid credentials!")

    def register(self):
        username = self.username_entry.get().strip()
        password = self.password_entry.get().strip()
        if self.db.register_user(username, password):
            messagebox.showinfo("Success", "User registered. Please login.")
        else:
            messagebox.showerror("Error", "Registration failed. Username may already exist.")

    def open_main_menu(self, user_id):
        root = tk.Tk()
        MainMenu(root, self.db, user_id)
        root.mainloop()


class MainMenu:
    def __init__(self, master, db, user_id):
        self.master = master
        self.db = db
        self.user_id = user_id
        master.title("Main Menu")
        master.geometry("300x200")

        tk.Label(master, text="Welcome to SafePass!").pack(pady=10)
        tk.Button(master, text="Generate Password", command=self.open_generator).pack(pady=5)
        tk.Button(master, text="View My Passwords", command=self.open_viewer).pack(pady=5)
        tk.Button(master, text="Logout", command=self.logout).pack(pady=5)

    def open_generator(self):
        # Open password generator page as a new window.
        password_generator.open_password_generator(self.db, self.user_id)

    def open_viewer(self):
        # Open the view passwords page as a new window.
        viewpassword.open_view_passwords(self.db, self.user_id)

    def logout(self):
        self.master.destroy()
        root = tk.Tk()
        LoginPage(root, self.db)
        root.mainloop()


if __name__ == "__main__":
    db = DatabaseManager()
    root = tk.Tk()
    LoginPage(root, db)
    root.mainloop()

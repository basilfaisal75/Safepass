import tkinter as tk  # Import tkinter for building the GUI
from tkinter import messagebox  # Import messagebox for popup dialogs
import secrets, string  # Import secrets for cryptographically secure random choices and string for character sets
from random import shuffle  # Import shuffle to randomly re-order elements in a list


# This class handles password generation and strength evaluation.
class PasswordGenerator:
    # Method to generate a password based on provided answers to security questions.
    def generate_password(self, answers):
        # Build a raw password using substrings extracted from each answer.
        # For example: first 2 characters of answer 0, last 2 of answer 1, underscore, etc.
        raw_password = f"{answers[0][:2]}{answers[1][-2:]}_{answers[2][:3]}{answers[3][-2:]}{answers[4]}"

        # Ensure the password length is within the desired range (10 to 12 characters).
        if len(raw_password) < 10:
            # If too short, append random letters until it reaches 10 characters.
            while len(raw_password) < 10:
                raw_password += secrets.choice(string.ascii_letters)
        elif len(raw_password) > 12:
            # If too long, truncate the password to 12 characters.
            raw_password = raw_password[:12]

        # Convert the password string into a list for further manipulation.
        password_list = list(raw_password)

        # Enforce complexity: ensure there is at least one uppercase letter.
        if not any(c.isupper() for c in password_list):
            # Choose a random position and replace with a random uppercase letter.
            pos = secrets.choice(range(len(password_list)))
            password_list[pos] = secrets.choice(string.ascii_uppercase)

        # Enforce complexity: ensure there is at least one digit.
        if not any(c.isdigit() for c in password_list):
            # Choose a random position and replace with a random digit.
            pos = secrets.choice(range(len(password_list)))
            password_list[pos] = secrets.choice(string.digits)

        # Enforce complexity: ensure there is at least one punctuation character.
        if not any(c in string.punctuation for c in password_list):
            # Choose a random position and replace with a random punctuation character.
            pos = secrets.choice(range(len(password_list)))
            password_list[pos] = secrets.choice(string.punctuation)

        # Randomly shuffle the characters in the password list to further secure the pattern.
        shuffle(password_list)

        # Return the final password as a string.
        return ''.join(password_list)

    # Method to evaluate and return the strength of a given password.
    def check_strength(self, password):
        score = 0  # Initialize a score counter

        # Increase score if the password meets minimum length requirements.
        if len(password) >= 10:
            score += 1
        if len(password) >= 12:
            score += 1

        # Increase score if password contains both lowercase and uppercase characters.
        if any(c.islower() for c in password) and any(c.isupper() for c in password):
            score += 1

        # Increase score if password contains at least one digit.
        if any(c.isdigit() for c in password):
            score += 1

        # Increase score if password contains at least one punctuation character.
        if any(c in string.punctuation for c in password):
            score += 1

        # Return a descriptive strength level based on the total score.
        if score >= 5:
            return "Very Strong"
        elif score == 4:
            return "Strong"
        elif score == 3:
            return "Moderate"
        else:
            return "Weak"


# This class creates the UI for generating a password.
class PasswordGeneratorUI:
    def __init__(self, master, db, user_id):
        self.master = master  # Reference to the current tkinter window
        self.db = db  # Database manager instance used for saving passwords
        self.user_id = user_id  # ID of the logged-in user
        self.generator = PasswordGenerator()  # Create an instance of PasswordGenerator

        # Set window title and dimensions for the password generator interface.
        master.title("Generate Password")
        master.geometry("400x500")

        # Define a list of security questions to be answered by the user.
        self.questions = [
            "What is your favorite color?",
            "What is your pet's name?",
            "What is your mother's name?",
            "What city were you born in?",
            "What is the year you were born in?"
        ]

        # List to store the entry widgets corresponding to each question.
        self.entries = []
        # Loop through each question, create a label and an entry field, and add them to the GUI.
        for question in self.questions:
            tk.Label(master, text=question).pack(pady=2)  # Display the question with some padding.
            entry = tk.Entry(master, width=40)  # Create an entry widget with a specified width.
            entry.pack(pady=2)  # Pack the entry widget into the window.
            self.entries.append(entry)  # Add the entry widget to the entries list.

        # Create a button that triggers the generate_password method when clicked.
        tk.Button(master, text="Generate Password", command=self.generate_password).pack(pady=10)

        # Label to display the generated password using a bold font.
        self.password_label = tk.Label(master, text="", font=("Helvetica", 12, "bold"))
        self.password_label.pack(pady=10)

        # Label to display the evaluated strength of the generated password.
        self.strength_label = tk.Label(master, text="", font=("Helvetica", 10))
        self.strength_label.pack(pady=10)

    # Method called when the "Generate Password" button is clicked.
    def generate_password(self):
        # Retrieve answers from all entry fields, trimming any extra whitespace.
        answers = [entry.get().strip() for entry in self.entries]

        # Check if any answer is missing; if so, show an error and stop further processing.
        if any(not answer for answer in answers):
            messagebox.showerror("Error", "Please answer all questions.")
            return

        # Generate a password using the answers provided.
        generated_password = self.generator.generate_password(answers)

        # Evaluate the strength of the generated password.
        strength = self.generator.check_strength(generated_password)

        # Update the UI labels to display the generated password and its strength.
        self.password_label.config(text=f"Generated Password:\n{generated_password}")
        self.strength_label.config(text=f"Password Strength: {strength}")

        # Save the generated password and its strength in the database for the current user.
        self.db.save_password(self.user_id, generated_password, strength)

        # Inform the user that the password was successfully generated and saved.
        messagebox.showinfo("Success", "Password generated and saved!")


# Function to open the password generator interface in a new top-level window.
def open_password_generator(db, user_id):
    # Create a new top-level window.
    window = tk.Toplevel()
    # Instantiate the PasswordGeneratorUI with the new window, database manager, and user id.
    PasswordGeneratorUI(window, db, user_id)
    # Start the window's event loop, making it interactive.
    window.mainloop()

import sqlite3
import logging
import bcrypt

# Configure logging for database-related messages.
logging.basicConfig(level=logging.INFO, filename="safepass.log",
                    format="%(asctime)s - %(levelname)s - %(message)s")

class DatabaseManager:
    def __init__(self):
        # Connect to (or create) the SQLite database file.
        self.conn = sqlite3.connect('safepass_app.db')
        self.create_tables()

    def create_tables(self):
        with self.conn:
            self.conn.execute('''
                CREATE TABLE IF NOT EXISTS users (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    username TEXT NOT NULL UNIQUE,
                    password BLOB NOT NULL
                )
            ''')
            self.conn.execute('''
                CREATE TABLE IF NOT EXISTS passwords (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER NOT NULL,
                    password TEXT NOT NULL,
                    strength TEXT NOT NULL,
                    FOREIGN KEY(user_id) REFERENCES users(id)
                )
            ''')
        logging.info("Database tables (users and passwords) are ready.")

    def register_user(self, username, password):
        try:
            hashed_pw = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())
            with self.conn:
                self.conn.execute("INSERT INTO users (username, password) VALUES (?, ?)", (username, hashed_pw))
            return True
        except sqlite3.IntegrityError:
            return False

    def login_user(self, username, password):
        cur = self.conn.cursor()
        cur.execute("SELECT id, password FROM users WHERE username = ?", (username,))
        row = cur.fetchone()
        if row:
            user_id, hashed_pw = row
            # Fix: ensure the hashed password is in bytes (needed for bcrypt)
            if isinstance(hashed_pw, str):
                hashed_pw = hashed_pw.encode('utf-8')
            if bcrypt.checkpw(password.encode('utf-8'), hashed_pw):
                return user_id
        return None

    def save_password(self, user_id, password, strength):
        with self.conn:
            self.conn.execute("INSERT INTO passwords (user_id, password, strength) VALUES (?,?,?)",
                              (user_id, password, strength))
        logging.info("Password saved to database for user_id %s.", user_id)

    def get_passwords(self, user_id):
        cur = self.conn.cursor()
        cur.execute("SELECT password, strength FROM passwords WHERE user_id = ?", (user_id,))
        return cur.fetchall()

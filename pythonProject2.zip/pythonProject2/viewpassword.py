import tkinter as tk  # Import the tkinter library for building the GUI


# This class creates a user interface (UI) for viewing saved passwords.
class ViewPasswordsUI:
    def __init__(self, master, db, user_id):
        # Initialize the UI with the provided tkinter window, database manager, and current user ID
        self.master = master  # Main window reference
        self.db = db  # Database manager instance for data access
        self.user_id = user_id  # Identifier for the current user

        # Set the window title to indicate what the page is for
        master.title("View My Passwords")
        # Define the size of the window (width x height)
        master.geometry("400x400")

        # Create and display a label at the top of the window with a bold font
        tk.Label(master, text="Your Saved Passwords:", font=("Helvetica", 12, "bold")).pack(pady=10)

        # Retrieve the saved passwords for the current user from the database
        passwords = self.db.get_passwords(self.user_id)

        # Check if the user has any saved passwords
        if not passwords:
            # If no passwords exist, display a message informing the user
            tk.Label(master, text="No passwords found.").pack(pady=10)
        else:
            # Create a Listbox widget to display the list of passwords
            listbox = tk.Listbox(master, width=50)
            # Place the Listbox in the window with some padding and allow it to expand with the window size
            listbox.pack(pady=10, fill=tk.BOTH, expand=True)

            # Iterate through the list of passwords retrieved from the database
            for pwd, strength in passwords:
                # Insert each password and its associated strength into the Listbox.
                # The format displays the password followed by its strength in parentheses.
                listbox.insert(tk.END, f"{pwd}  ({strength})")


# Function to open the password viewing window as a separate top-level window
def open_view_passwords(db, user_id):
    # Create a new top-level window (child window) for viewing passwords
    window = tk.Toplevel()
    # Instantiate the ViewPasswordsUI with the new window, database, and user id
    ViewPasswordsUI(window, db, user_id)
    # Start the event loop for this window, allowing it to be interactive
    window.mainloop()
